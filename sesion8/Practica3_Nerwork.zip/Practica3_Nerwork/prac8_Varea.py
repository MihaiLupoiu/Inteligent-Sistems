# -*- coding: utf-8 -*-
"""
Created on Tue Apr 09 09:39:25 2013

@author: Sergio Varea   
"""
from readTrafficSigns import readTrafficSigns
import matplotlib.pyplot as plt
from scipy.misc import imresize
from numpy import *

def histeq(im,nbr_bins=256):

   #get image histogram
   imhist,bins = histogram(im.flatten(),nbr_bins,normed=True)
   cdf = imhist.cumsum() #cumulative distribution function
   cdf = 255 * cdf / cdf[-1] #normalize

   #use linear interpolation of cdf to find new pixel values
   im2 = interp(im.flatten(),bins[:-1],cdf)

   return im2.reshape(im.shape), cdf

classes = [3,7,13,14]

tracks ={3: 5, 7: 40, 13: 24, 14: 8}

trainImages, trainDims, trainROIs, trainLabels, filenames = readTrafficSigns('.', classes, tracks)
img_new= []

for i in range(len(trainImages)):
    img=trainImages[i]
    x1= trainROIs[i][0][0]
    x2= trainROIs[i][1][0]
    y1=trainROIs[i][0][1]
    y2= trainROIs[i][1][1]

    plt.imshow(img,origin='lower')
    plt.draw()
    plt.ioff()
    plt.show()

    crop_img = img[x1:x2, y1:y2, :]
    plt.imshow(crop_img,origin='lower')
    plt.draw()
    plt.ioff()
    plt.show()

    scale_img=imresize(crop_img,(15,15))
    plt.imshow(scale_img,origin='lower')
    plt.draw()
    plt.ioff()
    plt.show()

    cropred_img=scale_img[:,:,0]
    plt.imshow(cropred_img,origin='lower')
    plt.gray()
    plt.draw()
    plt.ioff()
    plt.show()

    histogram_img ,cdf = histeq(cropred_img)
    plt.imshow(histogram_img,origin='lower')
    plt.draw()
    plt.ioff()
    plt.show()

    norm_img = (histogram_img-128)/256
    plt.imshow(norm_img,origin='lower')
    plt.draw()
    plt.ioff()
    plt.show()
    img_new.append(norm_img)
