# -*- coding: utf-8 -*-
from readTrafficSigns import readTrafficSigns
from scipy import ndimage, misc
import matplotlib.pyplot as plt
from PIL import Image

#función de escalado
def imresize(a, nx, ny, **kw):
    return ndimage.affine_transform(
        a, [(a.shape[0]-1)*1.0/nx, (a.shape[1]-1)*1.0/ny],
        output_shape=[nx,ny], **kw)

classes = [3, 7, 13, 14]

tracks = {3: 4, 7: 39, 13: 25, 14: 7}

trainImages, trainDims, trainROIs, trainLabels, filenames = readTrafficSigns('.', classes, tracks)

cropImages = [0]*len(trainImages)
redCrop = [0]*len(trainImages)

print trainImages[0]

for i in range(len(trainImages)):
    cropImages[i] = trainImages[i][trainROIs[i][0][0]:trainROIs[i][1][0], trainROIs[i][0][1]:trainROIs[i][1][1]]
    cropImages[i] = misc.imresize(cropImages[i],(15,15),'cubic')
    for j in range(len(cropImages[i])):
        for k in range(len(cropImages[i][0])):
            cropImages[i][j][k] = cropImages[i][j][k][0], 0, 0


print "\n\n\n croped\n\n", cropImages[0]

plt.imshow(cropImages[1])
plt.show()